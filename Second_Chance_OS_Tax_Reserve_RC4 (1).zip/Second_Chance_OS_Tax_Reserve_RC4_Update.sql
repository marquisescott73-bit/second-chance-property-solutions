-- SECOND CHANCE OS · TAX RESERVE CENTER RC4
-- Run once in Supabase SQL Editor. Existing tables and records are not deleted.

create table if not exists public.business_expenses (
  organization_id uuid not null references public.organizations(id) on delete cascade,
  id text not null,
  property_id text,
  unit_id text,
  payload jsonb not null default '{}'::jsonb,
  updated_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (organization_id, id)
);

create table if not exists public.tax_reserve_transfers (
  organization_id uuid not null references public.organizations(id) on delete cascade,
  id text not null,
  payload jsonb not null default '{}'::jsonb,
  updated_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (organization_id, id)
);

create table if not exists public.tax_settings (
  organization_id uuid not null references public.organizations(id) on delete cascade,
  id text not null default 'default',
  payload jsonb not null default '{}'::jsonb,
  updated_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (organization_id, id)
);

create index if not exists business_expenses_org_unit_idx on public.business_expenses (organization_id, unit_id);
create index if not exists business_expenses_org_property_idx on public.business_expenses (organization_id, property_id);
create index if not exists tax_transfers_org_created_idx on public.tax_reserve_transfers (organization_id, created_at desc);

alter table public.business_expenses enable row level security;
alter table public.tax_reserve_transfers enable row level security;
alter table public.tax_settings enable row level security;

drop policy if exists business_expenses_owner_select on public.business_expenses;
drop policy if exists business_expenses_owner_manage on public.business_expenses;
drop policy if exists tax_transfers_owner_select on public.tax_reserve_transfers;
drop policy if exists tax_transfers_owner_manage on public.tax_reserve_transfers;
drop policy if exists tax_settings_owner_select on public.tax_settings;
drop policy if exists tax_settings_owner_manage on public.tax_settings;

create policy business_expenses_owner_select on public.business_expenses
for select to authenticated
using (public.member_role(organization_id) = 'owner'::public.app_role);

create policy business_expenses_owner_manage on public.business_expenses
for all to authenticated
using (public.member_role(organization_id) = 'owner'::public.app_role)
with check (public.member_role(organization_id) = 'owner'::public.app_role);

create policy tax_transfers_owner_select on public.tax_reserve_transfers
for select to authenticated
using (public.member_role(organization_id) = 'owner'::public.app_role);

create policy tax_transfers_owner_manage on public.tax_reserve_transfers
for all to authenticated
using (public.member_role(organization_id) = 'owner'::public.app_role)
with check (public.member_role(organization_id) = 'owner'::public.app_role);

create policy tax_settings_owner_select on public.tax_settings
for select to authenticated
using (public.member_role(organization_id) = 'owner'::public.app_role);

create policy tax_settings_owner_manage on public.tax_settings
for all to authenticated
using (public.member_role(organization_id) = 'owner'::public.app_role)
with check (public.member_role(organization_id) = 'owner'::public.app_role);

drop trigger if exists set_business_expenses_updated_at on public.business_expenses;
create trigger set_business_expenses_updated_at before update on public.business_expenses
for each row execute function public.set_updated_at();

drop trigger if exists set_tax_reserve_transfers_updated_at on public.tax_reserve_transfers;
create trigger set_tax_reserve_transfers_updated_at before update on public.tax_reserve_transfers
for each row execute function public.set_updated_at();

drop trigger if exists set_tax_settings_updated_at on public.tax_settings;
create trigger set_tax_settings_updated_at before update on public.tax_settings
for each row execute function public.set_updated_at();

grant select, insert, update, delete on public.business_expenses to authenticated;
grant select, insert, update, delete on public.tax_reserve_transfers to authenticated;
grant select, insert, update, delete on public.tax_settings to authenticated;
