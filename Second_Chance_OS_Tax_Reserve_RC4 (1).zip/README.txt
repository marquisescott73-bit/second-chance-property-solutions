SECOND CHANCE OS · TAX RESERVE CENTER RC4

WHAT THIS BUILD DOES
- Keeps the public website and private #app in one online GitHub Pages file.
- Adds an Owner-only Tax Reserve tab.
- Recalculates when invoice income/payments, expenses, payroll time, hourly rates, tax settings, or saved/paid tax records change.
- Shows per-job business reserve, Marquise reserve, Caprice reserve, total reserve, and after-reserve cash.
- Shows 2026 quarterly estimated-tax due dates.
- Renders cached records immediately so the app does not sit on a blank screen while cloud tables load.
- Treats optional/missing cloud tables as warnings instead of blanking the entire workspace.

INSTALL
1. Run Second_Chance_OS_Tax_Reserve_RC4_Update.sql in Supabase SQL Editor.
2. Replace the GitHub repository root index.html with the new index.html.
3. Commit directly to main. Do not change GitHub Pages settings.
4. Wait 2–5 minutes, open the public website, then tap Client & Team Login.
5. Sign in as Owner and open Tax Reserve.

DEFAULT PLANNING SETTINGS
- Washington B&O: 1.50% (confirm classification).
- City B&O: 0.00% until entered.
- Employer FICA: 7.65%.
- FUTA effective planning rate: 0.60%.
- Washington UI placeholder: 1.00% — replace with the business-assigned ESD rate.
- Profit allocation: Marquise 50%, Caprice 50%.
- Personal planning reserve: 25% each.

IMPORTANT
This is a planning calculator, not a tax return or tax advice. Confirm federal treatment of the LLC/trust, deductions, credits, payroll taxes, Washington classifications, city taxes, and personal estimated payments with a qualified tax professional.
